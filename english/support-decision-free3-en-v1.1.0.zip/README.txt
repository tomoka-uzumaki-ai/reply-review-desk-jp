Support Decision Practice - English
Unzip all files together and open index.html in a browser with JavaScript and local HTML support. Phone support depends on your viewer. Ten fictional cases in the paid edition; three in the free sample. Manually save answers and current case as JSON before closing. Reload it in the same exact workbook and language. No automatic saving or network requests.
AI-assisted original fiction/code. Learning within the recipient organization only; no redistribution, resale or public uploads. No automated reply/refund decision or professional certification.

v1.1.0
Progress JSON is limited to32KB and requires the same case content.
