返信の判断をそろえる
無料3ケース見本
ZIPを展開し、同じフォルダーにファイルを保ってindex.htmlをJavaScriptが使える対応ブラウザで開いてください。Python・ログイン・AI API契約は不要です。スマホではZIP展開とローカルHTMLに対応する閲覧アプリが必要です。
架空店舗の方針だけを根拠に、次の担当者の作業を選びます。根拠と引継ぎ例を確認し、振り返りをTXTで保存できます。再読み込みで画面の進行は消えるため、閉じる前に回答と現在位置をJSONで手動保存し、次回同じ教材・言語で読み込んでください。入力送信・自動返信・実際の返金・個別相談はありません。
全ケースの相談・方針・事実は自作の架空例です。実際の購入者の権利、法的判断、売場や実店舗の規約は決めません。

v1.1.1
進行JSONは32KBまで。ケース内容の違う教材では復元できません。


File-selection correction: a newer selection or intervening edit cancels an older pending restore. Saved data formats and included files are unchanged.
